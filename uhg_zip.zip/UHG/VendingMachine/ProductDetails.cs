﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class ProductDetails
    {
        public List<string[]> data = new List<string[]>() {
                   new string[] {"1)", "Cola", "$1.00"},
                   new string[] {"2)", "Chips", "$0.50"},
                   new string[] {"3)", "Candy", "$0.65"},
                 };

        public string[] validInputs = { "0.01", "0.05", "0.10", "0.25" };

        public string[] returnCoin = { "0.01" };
    }
}
