﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    public class Entities
    {
        /// <summary>
        /// 
        /// </summary>
        public string option { get; set; }
    }
}
