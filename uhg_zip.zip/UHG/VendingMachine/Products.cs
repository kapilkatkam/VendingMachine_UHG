﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    public class Products
    {
        double currentAmount = 0.00;
        int valid = 0;
        int returnCoin = -1;
        ProductDetails pd = new ProductDetails();
        public void Display(Entities objEnt)
        {
            Console.Clear();

            string optValue = objEnt.option;
            if (pd.data != null)
            {
                if (pd.data.Count > 0)
                {
                    Console.WriteLine(string.Join(" ", pd.data[Convert.ToInt32(optValue.Trim()) - 1]));
                    string listItem = string.Join(" ", pd.data[Convert.ToInt32(optValue.Trim()) - 1]);
                    string[] arr = listItem.Split(" ");
                    if (arr.Length > 1)
                    {
                        string[] cost = arr[2].Split("$");
                        if (cost.Length > 0)
                        {
                            displayProductAmt(Convert.ToDouble(cost[1].ToString()));
                        }
                    }
                }
            }
        }

        public void displayProductAmt(double cost)
        {
            while (cost >= currentAmount)
            {
                if (currentAmount == cost)
                {
                    Console.WriteLine("Thank You");
                    break;
                }
                else if (currentAmount > cost)
                {
                    Console.WriteLine("Coin Return " + (currentAmount - cost) + "");
                    Console.WriteLine("Thank You Item Dispensed");
                    break;
                }
                else
                {
                    Console.WriteLine("Please Insert Coin");

                    string input = Console.ReadLine();

                    isVaild(input.Trim());
                    if (valid == -1)
                    {
                        Console.WriteLine("Coin Return " + input.Trim() + "");
                    }
                    else
                    {
                        isReturnCoin(input.Trim());
                        if (returnCoin == 0)
                        {
                            Console.WriteLine("Coin Return " + input.Trim() + "");
                        }
                        else
                        {
                            calculateAmt(input.Trim());
                            Console.WriteLine("Price $" + cost + " Current Amount $" + currentAmount + "");
                            if (currentAmount > cost)
                            {
                                Console.WriteLine("Coin Return " + Math.Round((currentAmount - cost), 2) + "");
                                Console.WriteLine("Thank You Item Dispensed");
                                break;
                            }
                        }
                    }
                }
            }
        }


        public double calculateAmt(string input)
        {
            currentAmount += Convert.ToDouble(input.Trim());
            currentAmount = Math.Round(currentAmount, 2);
            return currentAmount;
        }

        public int isVaild(string input)
        {
            valid = Array.IndexOf(pd.validInputs, input.Trim());
            return valid;
        }

        public int isReturnCoin(string input)
        {
            returnCoin = Array.IndexOf(pd.returnCoin, input.Trim());
            return returnCoin;
        }
    }
}
