﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class Menu
    {
        public void Display()
        {
            ProductDetails pd = new ProductDetails();
            PrintHeader();
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("Please Select a Product");

                foreach (var array in pd.data)
                    Console.WriteLine(string.Join(" ", array));

                Console.WriteLine("Which product do you want to select?");
                string input = Console.ReadLine();

                if (input.Trim() == "1" || input.Trim() == "2" || input.Trim() == "3")
                {
                    getOption(input.Trim());
                }
                else
                {
                    Console.WriteLine("Please Enter a valid product.");
                }
                Console.ReadLine();
                Console.Clear();
            }
        }

        private static void getOption(string input)
        {
            Entities objEnt = new Entities();
            objEnt.option = input.Trim();
            Products p = new Products();
            p.Display(objEnt);
        }

        private static void PrintHeader()
        {
            Console.WriteLine("WELCOME TO VENDING MACHINE");
        }


    }
}
