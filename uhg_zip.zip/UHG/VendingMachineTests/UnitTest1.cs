using Microsoft.VisualStudio.TestTools.UnitTesting;
using VendingMachine;

namespace VendingMachineTests
{
    [TestClass]
    public class UnitTest1
    {
        [DataTestMethod]
        [DataRow("0.05", 0.05)]
        [DataRow("0.25", 0.25)]
        [DataRow("0.4445", 0.44)]
        [DataRow("0.01", 0.01)]
        public void TestMethodCalculate(string input, double expected)
        {
            Products p = new Products();
            double result = p.calculateAmt(input);
            Assert.AreEqual(result, expected);
        }

        [DataTestMethod]
        [DataRow("0.01", 0)]
        [DataRow("0.05", 1)]
        [DataRow("0.10", 2)]
        [DataRow("0.25", 3)]
        [DataRow("0.30", -1)]
        public void TestMethodIsValid(string input, int expected)
        {
            Products p = new Products();
            int result = p.isVaild(input);
            Assert.AreEqual(result, expected);
        }

        [DataTestMethod]
        [DataRow("0.01", 0)]
        [DataRow("0.05", -1)]
        [DataRow("0.10", -1)]
        public void TestMethodisReturnCoin(string input, int expected)
        {
            Products p = new Products();
            int result = p.isReturnCoin(input);
            Assert.AreEqual(result, expected);
        }
    }
}
